tipo_cambio = 7.80
total = 0
for usd in range (10, 101, 10):
    quetzales = usd * tipo_cambio
    print (usd, usd * tipo_cambio)
    total = total + (usd * tipo_cambio)