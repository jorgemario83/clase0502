productos = ["laptop", "mouse", "teclado"]
for n, p in enumerate (productos, start=1):
    print (f"#{n}: {p}")