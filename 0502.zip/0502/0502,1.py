#con for loop
gastos = [500, 500, 500, 500, 500]

total = 0
for gasto in gastos:
    total = total + gasto #suma cada elemnto

print (f"total: Q{total}")    