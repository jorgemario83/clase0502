prod = ["papel", "lapiceros", "cuadernos"]
stock = [45, 120, 85]
for n, p in enumerate (prod, start=1):
    print (f"[{n}]{p}:{stock[n-1]}")
    cant = stock[n-1]
if cant <50:
    aviso = " [!]Bajo Stock"