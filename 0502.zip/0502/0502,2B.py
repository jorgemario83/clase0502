for numero in range (5):
    print (numero)
for numero in range (1, 6):
    print (numero)
for numero in range (0, 10, 2):
    print (numero)

precio_por_pagina = 2.50
for pagina in range (1, 6):
    total = pagina * precio_por_pagina
    print (f"{pagina} paginas: Q{total:.2f}")