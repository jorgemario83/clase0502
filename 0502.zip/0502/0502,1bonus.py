#con for loop
gastos = [1200, 350, 450, 875, 600]

total = 0
for gasto in gastos:
#que va a aqui?
    total = total + gasto  
print(f"Sumando Q{gasto}... Total ahora: Q{total}")
print(f"Total: Q{total}")