ventas = [150000, 220000, 180000, 250000]

for posicion, venta in enumerate (ventas):
    print(f"{posicion + 1}lugar Q{venta}")